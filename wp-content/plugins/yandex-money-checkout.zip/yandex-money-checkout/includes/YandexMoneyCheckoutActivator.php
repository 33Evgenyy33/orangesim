<?php

/**
 * Fired during plugin activation.
 */
class YandexMoneyCheckoutActivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
