=== WooCommerce Local Pickup Plus ===
Author: skyverge
Tags: woocommerce
Requires at least: 4.4
Tested up to: 4.9.2

A shipping plugin for WooCommerce that allows the store operator to define local pickup locations, which the customer can then choose from when making a purchase.

See http://docs.woocommerce.com/document/local-pickup-plus/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-shipping-local-pickup-plus' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
