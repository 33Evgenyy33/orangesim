<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Editing_Model_Disabled extends ACP_Editing_Model {

	public function register_settings() {
		// Settings Disabled. Leave empty.
	}

}
