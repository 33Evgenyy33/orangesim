<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AC_Form_Element_Radio extends AC_Form_Element_Checkbox {

	protected function get_type() {
		return 'radio';
	}

}
