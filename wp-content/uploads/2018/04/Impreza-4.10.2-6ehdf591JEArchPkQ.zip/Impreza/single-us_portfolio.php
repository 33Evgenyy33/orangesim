<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * The template for displaying portfolio pages
 *
 * Do not overload this file directly. Instead have a look at framework/templates/single-us_portfolio.php:
 * you should find all the needed hooks there.
 */

us_load_template( 'templates/single-us_portfolio' );
